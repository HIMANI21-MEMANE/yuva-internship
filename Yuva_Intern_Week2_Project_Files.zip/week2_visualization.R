# Yuva Intern Week 2: Data Visualization and Insight Communication using R
# Dataset: public Titanic passenger dataset
# Source: https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv
# Install once if needed: install.packages(c("ggplot2", "dplyr"))
library(ggplot2)
library(dplyr)

url <- "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
titanic <- read.csv(url, stringsAsFactors = FALSE, na.strings = c("", "NA"))
titanic$SurvivedLabel <- factor(titanic$Survived, levels=c(0,1),
                                labels=c("Did not survive","Survived"))
titanic$PclassLabel <- factor(titanic$Pclass, levels=c(1,2,3),
                              labels=c("First","Second","Third"))
titanic$Sex <- factor(titanic$Sex)

# 1. Bar chart: overall survival counts
p1 <- ggplot(titanic, aes(x=SurvivedLabel, fill=SurvivedLabel)) +
  geom_bar(show.legend=FALSE) + labs(title="Overall survival outcomes",
  x="Outcome", y="Passenger count") + theme_minimal()
ggsave("week2_overall_survival_bar.png", p1, width=7, height=4.5, dpi=180)

# 2. Stacked bar chart: survival by sex
p2 <- ggplot(titanic, aes(x=Sex, fill=SurvivedLabel)) + geom_bar() +
  labs(title="Survival outcomes by sex", x="Sex", y="Passenger count",
       fill="Outcome") + theme_minimal()
ggsave("week2_survival_by_sex.png", p2, width=7, height=4.5, dpi=180)

# 3. Histogram: passenger ages
p3 <- ggplot(titanic, aes(x=Age)) + geom_histogram(binwidth=5, color="white") +
  labs(title="Distribution of passenger ages", x="Age (years)",
       y="Passenger count") + theme_minimal()
ggsave("week2_age_histogram.png", p3, width=7, height=4.5, dpi=180)

# 4. Scatter plot: fare versus age, coloured by survival
p4 <- ggplot(titanic, aes(x=Age, y=Fare, color=SurvivedLabel)) +
  geom_point(alpha=.55, na.rm=TRUE) + scale_y_continuous(trans="sqrt") +
  labs(title="Fare versus age by survival outcome",
       subtitle="Square-root y-axis helps inspect lower fares",
       x="Age (years)", y="Fare (square-root scale)", color="Outcome") +
  theme_minimal()
ggsave("week2_fare_vs_age_scatter.png", p4, width=7, height=4.5, dpi=180)

# 5. Line chart: survival rate by ordered passenger class
class_rates <- titanic %>% group_by(PclassLabel) %>%
  summarise(Passengers=n(), Survivors=sum(Survived==1, na.rm=TRUE),
            SurvivalRate=mean(Survived==1, na.rm=TRUE)*100, .groups="drop")
print(class_rates)
p5 <- ggplot(class_rates, aes(x=PclassLabel, y=SurvivalRate, group=1)) +
  geom_line() + geom_point(size=3) +
  geom_text(aes(label=paste0(round(SurvivalRate,1),"%")), vjust=-.8) +
  labs(title="Survival rate by passenger class",
       subtitle="The line connects ordered categories, not dates",
       x="Passenger class", y="Survival rate (%)") +
  coord_cartesian(ylim=c(0,75)) + theme_minimal()
ggsave("week2_survival_rate_by_class_line.png", p5, width=7, height=4.5, dpi=180)

# 6. Box plot: fare distribution by passenger class
p6 <- ggplot(titanic, aes(x=PclassLabel, y=Fare)) + geom_boxplot(outlier.alpha=.35) +
  labs(title="Ticket fare distribution by passenger class",
       x="Passenger class", y="Fare") + theme_minimal()
ggsave("week2_fare_boxplot_by_class.png", p6, width=7, height=4.5, dpi=180)

cat("Dimensions:", nrow(titanic), "rows x", ncol(titanic), "columns\\n")
cat("\\nSurvival counts:\\n"); print(table(titanic$SurvivedLabel))
cat("\\nSurvival by sex (row percentages):\\n")
print(round(prop.table(table(titanic$Sex, titanic$SurvivedLabel), 1)*100, 1))
cat("\\nSummary of Age and Fare:\\n"); print(summary(titanic[,c("Age","Fare")]))
cat("\\nMissing ages:", sum(is.na(titanic$Age)), "\\n")
write.csv(class_rates, "week2_survival_rate_by_class.csv", row.names=FALSE)
cat("\\nCharts and summary CSV saved to working directory.\\n")
