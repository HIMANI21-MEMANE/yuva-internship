# Yuva Intern Week 2: Data Visualization and Insight Communication using R

Files:
- `Yuva_Intern_Week2_Data_Visualization_Report.docx` — Word report
- `week2_visualization.R` — reproducible R script
- `submission_description.txt` — 200+ word portal description
- PNG images — supporting report charts

Run in RStudio:
1. Install R and RStudio.
2. Run `install.packages(c("ggplot2", "dplyr"))` once.
3. Set the working directory to this folder.
4. Run `source("week2_visualization.R")`.
5. Review console output and generated charts; capture genuine screenshots if required.
6. Verify the report against your actual run before submission.

Dataset source: https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv
